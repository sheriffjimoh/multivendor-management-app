<footer class="main-footer">
    <div class="pull-right hidden-xs">
      <b>All rights reserved</b>
    </div>
    <strong>Copyright &copy; 2020 <a href="mailto:jimohsherifdeen6s@gmail.com">Sheriff Tech</a></strong>
</footer>