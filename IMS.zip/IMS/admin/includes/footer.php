<footer class="main-footer">
    <div class="pull-right hidden-xs">
    <strong class="text-center text-info">Poweredby <a href="mailto:jimohsherifdeen6s@gmail.com">Sheriff Tech</a></strong>
    </div>
   
     <strong>Copyright &copy; 2020 ,     Alright reserved<a href="mailto:jimohsherifdeen6s@gmail.com"> &nbsp;Sheriff Tech</a></strong>
</footer>